% Parser setup for modelez syntax models

if(parseflag)
%     parsexpr = ['! /mq/home/aim/bin/mdlez-aim ',dirnam,modnam];
% I had to modify this line to the following in order to ensure the
%  _aim_data and _aim_matrices files came out in the dirnam directory
%  instead of my home directory.
%
  parsexpr = ['! cd ' dirnam '; /mq/home/aim/bin/mdlez-aim ',dirnam,modnam];
  eval(parsexpr);
end

% Run compute_aim_data:

[param_,np,modname,neq,nlag,nlead,eqname_,eqtype_,endog_,delay_,vtype_] = ...
	eval([modnam,'_aim_data']);

if(parseflag)
  seq  = find(eqtype_==0);
  dvar = find(vtype_==0);
  if(length(seq)~=length(dvar))
    disp(' ');
    warning('Number of data variables not equal to number of stochastic equations.');
    disp(' ');
  end
end
